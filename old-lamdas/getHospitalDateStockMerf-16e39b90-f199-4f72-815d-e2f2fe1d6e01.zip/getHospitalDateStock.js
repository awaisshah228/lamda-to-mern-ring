exports.handler = function (event, context)
{    
    var AWS = require('aws-sdk');
    AWS.config.region = 'us-east-1';
    var mysql = require('mysql');

	var con = JSON.parse(process.env.con);  
	var conn = mysql.createConnection(con.conn);
	
	var querystr = "call getHospitalDateStock('" + event.hospitalID + "', '" + event.date + "', '" + event.itemType + "')";       
	conn.query(querystr, function (err2, rowsstr) 
	{
		if (err2 == null)
		{
			conn.end(function(err11){});
			context.done(null, {"status": 0, "Description": "sucess", "data": rowsstr[0]});
		}
		else
		{
			conn.end(function(err11){});
			context.done(null, {"status": 1, "Description": "failed", "error": err2});
		}
	});
};
